﻿using ComicBookGallery.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ComicBookGallery.Data
{
    public class ComicBookRepository
    {
        public ComicBook[] GetComicBooks ()
        {
            return _comicBooks;
        }

        public ComicBook GetComicBook(int id)
        {
            foreach (ComicBook comicBook in _comicBooks)
            {
                if (comicBook.Id == id)
                {
                    return comicBook;
                }
            }
            return null;
        }

        private static ComicBook[] _comicBooks = new ComicBook[]
        {
            new ComicBook()
            {
                Id = 1,
                SeriesTitle = "Nevada",
                IssueNumber = 100,
                DescriptionHtml = "<p>Esta no es una historia de terror ni un cuento típico de Navidad, <strong>es más que eso:</strong> es una historia de amor para cualquier día del año. ¿Quieres saber por qué? Abrígate hasta arriba y prepárate para la gran nevada.</p>",
                Artists = new Artist[]
                {
                    new Artist() { Name = "Holden Centeno", Role = "Autor" },
                    new Artist() { Name = "Penguin", Role = "Editorial" },
                    new Artist() { Name = "Grupo Editorial", Role = "Editorial" },
                    new Artist() { Name = "Cuento", Role = "Genero" },
                    new Artist() { Name = "Español", Role = "Idiomas" },
                },
                Favorite = true,
            },
            new ComicBook()
            {
                Id = 2,
                SeriesTitle = "Paris",
                IssueNumber = 200,
                DescriptionHtml = "<p>Alicia y Manuel llevan años planeando viajar París, <strong>pero en el último momento siempre surge algo que lo impide</strong>. Esta vez ha sido el confinamiento, pero cuando no es una cosa es otra... Y es que así es la vida. Impredecible.</p>",
                Artists = new Artist[]
                {
                    new Artist() { Name = "Marisa Sicilia", Role = "Autor" },
                    new Artist() { Name = "Relato - Romantico", Role = "Generos" },
                    new Artist() { Name = "Español", Role = "Idiomas" },
                },
                Favorite = false
            },
            new ComicBook()
            {
                Id = 3,
                SeriesTitle = "Trajano",
                IssueNumber = 300,
                DescriptionHtml = "<p>Muchos creen que Trajano murió en la lejana Partia durante sus campañas en Oriente, pero eso no es exacto. <strong>Tampoco falleció en Roma ni en su Hispania natal</strong>. Es cierto que murió entre el 9 y el 10 de agosto del año 117 en el este del imperio, pero cuando ya se encontraba de regreso hacia Roma tras haber vencido a decenas de</p>",
                Artists = new Artist[]
                {
                    new Artist() { Name = "Santiago Posteguillo", Role = "Autor" },
                    new Artist() { Name = "Planeta", Role = "Editorial" },
                    new Artist() { Name = "Ficcion", Role = "Generos" },
                    new Artist() { Name = "Español", Role = "Idiomas" },
                },
                Favorite = false
            },
            new ComicBook()
            {
                Id = 4,
                SeriesTitle = "MuerteAcompañe",
                IssueNumber = 400,
                DescriptionHtml = "<p>Esta es la historia de Toscano y Paula, dos almas gemelas que no se conocen de mucho, pero que se intuyen demasiado. Toscano muere y descubre que, para entrar en el cielo, poco importa lo que hizo en vida, sino más bien cómo lo vende.</p>",
                Artists = new Artist[]
                {
                    new Artist() { Name = "Risto Mejide", Role = "Autor" },
                    new Artist() { Name = "Espasa", Role = "Editorial" },
                    new Artist() { Name = "Novela", Role = "Generos" },
                    new Artist() { Name = "Español", Role = "Idiomas" },
                },
                Favorite = false
            },
            new ComicBook()
            {
                Id = 5,
                SeriesTitle = "Laurie",
                IssueNumber = 500,
                DescriptionHtml = "<p>Stephen King nos regala un precioso relato sobre la vida, la pérdida y la esperanza. Lloyd, un hombre que acaba de perder a su mujer, recibe un «regalo» inesperado por parte de su hermana. Laurie, una adorable cachorrilla mezcla de Border Collie y Mudi, que poco a poco cambiará su vida para siempre.</p>",
                Artists = new Artist[]
                {
                    new Artist() { Name = "Stephen King", Role = "Autor" },
                     new Artist() { Name = "Flash Relatos", Role = "Editorial" },
                    new Artist() { Name = "Relato", Role = "Generos" },
                    new Artist() { Name = "Español", Role = "Idiomas" }
                },
                Favorite = false
            }
        };
    }
}